<template>
  <div id="app">
  

      <router-view></router-view>

  </div>



</template>
<script>
//import '@/assets/css/style.css'
//import login from './views/login.vue';
import "bootstrap/dist/css/bootstrap.css";
import "bootstrap-vue/dist/bootstrap-vue.css";
    export default {
        components: {
        //login
        },
        data () {
            return {

          }
      },
       methods: {
    }
    }
</script>
