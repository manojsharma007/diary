module.exports = {
  css: {
    loaderOptions: {
      sass: {
        prependData: `
		      @import "bootstrap/dist/css/bootstrap.css";
		      @import "bootstrap-vue/dist/bootstrap-vue.css";
        `,
      },
    },
  },
};
