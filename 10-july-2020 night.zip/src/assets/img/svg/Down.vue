<template>
  <div>
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 306 306"><path d="M35.7 58.65L153 175.951 270.3 58.65 306 94.351 153 247.35 0 94.351z"/></svg>
  </div>
</template>

<script>
  export default {

  }
</script>

<style>

</style>
