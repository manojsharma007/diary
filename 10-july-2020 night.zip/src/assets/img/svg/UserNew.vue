<template>
  <div>
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 561 561"><path d="M357 280.5c56.1 0 102-45.9 102-102s-45.9-102-102-102-102 45.9-102 102 45.9 102 102 102zm-229.5-51V153h-51v76.5H0v51h76.5V357h51v-76.5H204v-51h-76.5zm229.5 102c-68.85 0-204 33.15-204 102v51h408v-51c0-68.85-135.15-102-204-102z"/></svg>
  </div>
</template>

<script>
  export default {

  }
</script>

<style>

</style>
