<template>

  <div>
    <div class="submitbutton">

      <b-row class="text-center">
        <b-col>
          <b-button variant="info" style="width: 130px" @click="addjournal">Add journal </b-button>
        </b-col>
      </b-row>

    </div>
    <div class="main-wrapper diarylist">
      <section class="blog-list px-3 py-5 p-md-5">

        <div class="monthname">
          <h4>June 2020</h4>
        </div>
        <div class="container" v-for="(item) in this.listItems" :key="item.id">
          <div class="row">
            <div class="col-10">
              <a class="more-link" @click="viewjournal">
                <div class="intro">  <div v-html="item.text"> </div></div>
              </a>
              <div class="time">
                <span class="date">{{item.time}} , Hydrabad</span>
              </div>
            </div>
            <div class="col-2">
              <span> Sunday</span> <br>
              <h1>27 </h1>
            </div>
          </div>
        </div>

      </section>

    </div>

  </div>

</template>

<script>

  export default {
    data() {
      return {
        listItems:[]
      }
    },
    created() {
      if (localStorage.getItem('addjournal')) {
        this.listItems = JSON.parse(localStorage.getItem('addjournal'))
      }
    },
    methods: {
      addjournal() {
        this.$router.push({ name: 'addjournal' })
      },
      viewjournal() {
        this.$router.push({ name: 'viewjournal' })
      }
    }
  }

</script>
<style>

  .container {
    display: flex;
    flex-wrap: wrap;
    margin-right: 0px;
    margin-left: -15px;
    border-bottom: 1px gray solid;
    text-align: justify;
    margin-bottom: 10px;
  }
  .time {
    font-size: 12px;
    margin: 4px 0 12px 0;
  }
  .monthname {
    color: gray;
    background: #f7f7f9;
  }
  .diarylist {
    margin: -33px 0 0 0;
  }

</style>
