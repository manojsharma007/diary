<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 497.25 497.25"><path d="M248.625 89.25V0l-127.5 127.5 127.5 127.5V140.25c84.15 0 153 68.85 153 153s-68.85 153-153 153-153-68.85-153-153h-51c0 112.2 91.8 204 204 204s204-91.8 204-204-91.8-204-204-204z"/></svg>
</template>

<script>
  export default {

  }
</script>

<style>

</style>
