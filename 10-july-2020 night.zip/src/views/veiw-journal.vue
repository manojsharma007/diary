<template>

  <div class="viewjr">
    <div class="submitbutton">
      <b-row class="text-center">
        <b-col>
          <b-button variant="info" style="width: 130px" @click="addjournal">Add journal </b-button>
        </b-col>
      </b-row>

    </div>
    <div class="main-wrapper">
      <section class="blog-list">

        <div class="monthname">
          <h4>June 2020</h4>
        </div>

        <div class="row">

          <div class="intro viewjournal">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.Lorem
            ipsum dolor sit amet, consectetuer adipiscing elit.Lorem ipsum dolor sit amet, consectetuer adipiscing elit.Lorem
            ipsum dolor sit amet, consectetuer adipiscing elit.Lorem ipsum dolor sit amet, consectetuer adipiscing elit.Lorem
            ipsum dolor sit amet, consectetuer adipiscing elit.Lorem ipsum dolor sit amet, consectetuer adipiscing elit.Lorem
            ipsum dolor sit amet, consectetuer adipiscing elit.Lorem ipsum dolor sit amet, consectetuer adipiscing elit.Lorem
            ipsum dolor sit amet, consectetuer adipiscing elit.Lorem ipsum dolor sit amet, consectetuer adipiscing elit.Lorem
            ipsum dolor sit amet, consectetuer adipiscing elit.Lorem ipsum dolor sit amet, consectetuer adipiscing elit.Lorem
            ipsum dolor sit amet, consectetuer adipiscing elit. </div>

        </div>
        <b-row class="text-center">
          <b-col>
            <b-button style="margin:5px;" @click="goToDiarylist" variant="info">Back to List</b-button>
          </b-col>
        </b-row>

      </section>

    </div>

  </div>

</template>

<script>

  export default {
    methods: {
      goToDiarylist() {
        this.$router.push({ name: 'diarylist' })
      },
      addjournal() {
        this.$router.push({ name: 'addjournal' })
      }
    }
  }

</script>
<style>

  .blog-list {
    margin: 10px;
  }

  .viewjr {
    text-align: justify;
    margin: 15px;
  }

</style>
